/** Automatically generated file. DO NOT MODIFY */
package com.mygdx.game.android;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}