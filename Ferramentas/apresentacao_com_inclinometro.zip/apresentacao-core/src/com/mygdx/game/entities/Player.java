package com.mygdx.game.entities;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.InputProcessor;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.math.Vector3;
import com.mygdx.game.screens.Play;

public class Player extends Sprite implements InputProcessor{
	private Vector2 velocity = new Vector2();
	float speed = 60*2, gravity= 60*0.8f;
	public SpriteBatch batch;
	private int pontox=0,pontoy=0;
	public boolean movendox1=false;//x positivo
	public boolean movendox2=false;//x negativo
	public boolean movendoy1=false;//y positivo
	public boolean movendoy2=false;//y negativo
	
	
	
	public Player(Sprite sprite){
		super(sprite);
		batch = new SpriteBatch();
	}
	
	
	public void update(float delta){
		if (velocity.x>speed){
			velocity.x=speed;
		}
		if (velocity.x<-speed){
			velocity.x=-speed;
		}
		if (velocity.y>speed){
			velocity.y=speed;
		}
		if (velocity.y<-speed){
			velocity.y=-speed;
		}
		
		
		this.setX(this.getX()+velocity.x*delta);
		this.setY(this.getY()+velocity.y*delta);
		
		if (movendox1 && getX()+this.getWidth()/2>=pontox){
			movendox1=false;
			velocity.x=0;
		}
		if (movendoy1 && getY()+this.getHeight()/2>=pontoy){
			movendoy1=false;
			velocity.y=0;
		}
		if (movendox2 && getX()+this.getWidth()/2<=pontox){
			movendox2=false;
			velocity.x=0;
		}
		if (movendoy2 && getY()+this.getHeight()/2<=pontoy){
			movendoy2=false;
			velocity.y=0;
		}
		
		
		
		if (Gdx.input.getPitch()>30){
			velocity.x=-speed;
			movendox1=false;
			movendox2=false;
			movendoy1=false;
			movendoy2=false;
		} else if (Gdx.input.getPitch()<-30){
			velocity.x=speed;
			movendox1=false;
			movendox2=false;
			movendoy1=false;
			movendoy2=false;
		} else if (!movendox1 && !movendox2 && !movendoy1 && !movendoy2){
			velocity.x=0;
		}
		if (Gdx.input.getRoll()>30){
			velocity.y=speed;
			movendoy1=false;
			movendoy2=false;
			movendoy1=false;
			movendoy2=false;
		} else if (Gdx.input.getRoll()<-30){
			velocity.y=-speed;
			movendoy1=false;
			movendoy2=false;
			movendoy1=false;
			movendoy2=false;
		} else if (!movendox1 && !movendox2 && !movendoy1 && !movendoy2){
			velocity.y=0;
		}
		
		//Gdx.input.getPitch()	-180 <--->180
		//Gdx.input.getRoll()	-180 <--->180
		//Gdx.input.getAzimush()	-180 <--->180
		
	}


	public void draw (SpriteBatch spritebatch){
		update(Gdx.graphics.getDeltaTime());
		super.draw(batch);
	}
	
	@Override
	public boolean keyDown(int keycode) {
		// TODO Auto-generated method stub
		return false;
	}


	@Override
	public boolean keyUp(int keycode) {
		// TODO Auto-generated method stub
		return false;
	}


	@Override
	public boolean keyTyped(char character) {
		// TODO Auto-generated method stub
		return false;
	}


	@Override
	public boolean touchDown(int screenX, int screenY, int pointer, int button) {
		// TODO Auto-generated method stub
		return false;
	}


	@Override
	public boolean touchUp(int screenX, int screenY, int pointer, int button) {
		Vector3 ponto = Play.camera.unproject(new Vector3(screenX, screenY, 0));
		pontox=(int)ponto.x;
		pontoy=(int)ponto.y;
		
		if (pontox>getX()){
			velocity.x=speed;
			movendox1=true;
		}
		if (pontox<getX()){
			velocity.x=-speed;
			movendox2=true;
		}
		if (pontoy>getY()){
			velocity.y=speed;
			movendoy1=true;
		}
		if (pontoy<getY()){
			velocity.y=-speed;
			movendoy2=true;
		}
		
		return true;
	}


	@Override
	public boolean touchDragged(int screenX, int screenY, int pointer) {
		// TODO Auto-generated method stub
		return false;
	}


	@Override
	public boolean mouseMoved(int screenX, int screenY) {
		// TODO Auto-generated method stub
		return false;
	}


	@Override
	public boolean scrolled(int amount) {
		// TODO Auto-generated method stub
		return false;
	}
}
